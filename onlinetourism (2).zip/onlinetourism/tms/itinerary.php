<?php
session_start();
error_reporting(0);
include('includes/config.php');
?>
<!DOCTYPE HTML>
<html>
<head>
<title>TN  | Itinerary</title>
<style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f5f5f5;
        }

        h1 {
            color: #333;
            text-align: center;
            padding: 20px 0;
            margin: 0;
            background-color: #fff;
        }

        .event {
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            padding: 20px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
        }

        .event img {
            max-width: 200px;
            margin-right: 20px;
            border-radius: 5px;
        }

        .event h2 {
            margin-bottom: 10px;
            color: #333;
        }

        .event p {
            margin: 5px 0;
            color: #666;
        }
    </style>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="applijewelleryion/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,700,600' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,700,300' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>
<link href="css/font-awesome.css" rel="stylesheet">
<!-- Custom Theme files -->
<script src="js/jquery-1.12.0.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!--animate-->
<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
<script src="js/wow.min.js"></script>
	<script>
		 new WOW().init();
	</script>
<!--//end-animate-->

</head>
<body>
<?php include('includes/header.php');?>
<!--- banner ---->
<div class="banner-3">
	<div class="container">
		<h1 class="wow zoomIn animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: zoomIn;"> TN- Itineraray</h1>
	</div>
</div>
<!--- /banner ---->
<!--- rooms ---->
<div class="rooms">
	<div class="container">
		
		<div class="room-bottom">
			<!--<h3>Itinerary</h3>

					
<?php $sql = "SELECT * from tbltourpackages";
$query = $dbh->prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount() > 0)
{
foreach($results as $result)
{	?>
			<div class="rom-btm">
				<div class="col-md-3 room-left wow fadeInLeft animated" data-wow-delay=".5s">
					<img src="admin/pacakgeimages/<?php echo htmlentities($result->PackageImage);?>" class="img-responsive" alt="">
				</div>
				<div class="col-md-6 room-midle wow fadeInUp animated" data-wow-delay=".5s">
					<h4>Package Name: <?php echo htmlentities($result->PackageName);?></h4>
					<h6>Package Type : <?php echo htmlentities($result->PackageType);?></h6>
					<p><b>Package Location :</b> <?php echo htmlentities($result->PackageLocation);?></p>
					<p><b>Features</b> <?php echo htmlentities($result->PackageFetures);?></p>
				</div>
				<div class="col-md-3 room-right wow fadeInRight animated" data-wow-delay=".5s">
					<h5>Rupee <?php echo htmlentities($result->PackagePrice);?></h5>
					<a href="package-details.php?pkgid=<?php echo htmlentities($result->PackageId);?>" class="view">Details</a>
				</div>
				<div class="clearfix"></div>
			</div>

<?php }} ?>-->
<h3>Shimla-kullu manali</h3>

<div class="event">
    <img src="pinjore.jpg" >
    <div>
        <h2>Day 1: Travel from Delhi to Shimla</h2>
        <p>Location: Rock Garden, Pinjore Garden</p>
        <p> 7:00 AM - Rock Garden Sightseeing</p>
        <p>12:00 PM - Lunch at open garden terrace restraunt</p>
        <p>03:00 PM - Pinjore garden Sightseeing</p>
        <p>08:00 PM - Dinner at Pinjore dhaba</p>
        <h4>Overnight Stay in Shimla </h4>
    </div>
</div>
<div class="event">
    <img src="jakhu.jpg" alt="City B">
    <div>
        <h2>Day 2: Shimla Sightseeing</h2>
        <p>Location: Jakhu temple,Vice regal lodge,The Ridge </p>
        <p> 6:00 am -  Jakhu temple</p>
        <p>10:00 pm - Vice regal lodge</p>
        <p> 1:00 pm - lunch at Ashus kitchen</p>
        <p> 4:00 pm - The ridge </p>
        <p> 6:00 pm - Shopping</p>
        <p> 9:00 pm - Dinner at chopsticks</p>
        <h4>Overnight Stay in Shimla </h4>


    </div>
</div>

<div class="event">
    <img src="naggar.jpg" alt="City C">
    <div>
        <h2>Day 3: Visit Naggar & Travel to Manali</h2>
        <p>Location: Naggar Castle </p>
        <p>10:00 AM - Sightseeing</p>
        <p>01:00 PM - Lunch at Symphony</p>
        <h4>Overnight Stay in Manali </h4>
    </div>
</div>

<div class="event">
    <img src="Manu Temple.jpg" alt="City C">
    <div>
        <h2>Day 4: Manali Sightseeing</h2>
        <p>Location:  Hidimbi Devi Temple, Manu Temple, Jogini Waterfalls, Van Vihar</p>
        <p>10:00 AM - Hidimbi Devi Temple, Manu Temple Sightseeing</p>
        <p>01:00 PM - Lunch at Symphony</p>
        <p>03:00 PM - Jogini Waterfalls, Van Vihar</p>
        <h4>Overnight Stay in Manali </h4>
    </div>
</div>

<div class="event">
    <img src="solang.jpg" alt="City D">
    <div>
        <h2>Day 5: Solang valley- Gulaba</h2>
        <p>Location:Solang Valley, Kothi Village, Gulaba, Rahala Falls </p>
        <p>07:00 AM - Solang Valley</p>
        <p>10:00 AM - Kothi Village</p>
        <p>01:00 PM - Lunch at Ride In</p>
        <p>04:00 PM - Gulaba</p>
        <p>06:00 PM - Rahala Falls</p>
        <p>09:00 PM - Dinner at Bella Pasta</p>

        <h4>Overnight Stay in Manali </h4>
    </div>
</div>

<div class="event">
    <img src="dhakpo.jpg" alt="City C">
    <div>
        <h2>Day 6: Visit kullu</h2>
        <p>Location: Dhakpo Shedrupling Monastery </p>
        <p>10:00 AM - Sightseeing</p>
        <p>01:00 PM - Lunch at Cafe lounge</p>
        <h4>Overnight Stay in Kullu </h4>
        <h4>Now heading back to delhi </h4>

    </div>
</div>
	
		
		
		</div>
	</div>
</div>
<!--- /rooms ---->

<!--- /footer-top ---->
<?php include('includes/footer.php');?>
<!-- signup -->
<?php include('includes/signup.php');?>			
<!-- //signu -->
<!-- signin -->
<?php include('includes/signin.php');?>			
<!-- //signin -->
<!-- write us -->
<?php include('includes/write-us.php');?>			
<!-- //write us -->
</body>
</html>